package exceptions;

public class InvalidPileIdentifierException extends RuntimeException {
	private static final long serialVersionUID = 0;
}
